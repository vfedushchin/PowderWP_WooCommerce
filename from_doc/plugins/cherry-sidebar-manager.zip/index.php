<?php
/**
 * Silence is golden
 *
 * @package  Cherry Sidebar Manager
 * @category Core
 * @author   Cherry Team
 * @license  GPL-2.0+
 */
