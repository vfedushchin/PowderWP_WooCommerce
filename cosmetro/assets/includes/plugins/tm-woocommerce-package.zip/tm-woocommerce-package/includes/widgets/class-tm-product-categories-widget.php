<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Woocommerce Image Product Categories
 *
 * @author   WooThemes
 * @category Widgets
 * @package  WooCommerce/Widgets
 * @version  2.3.0
 * @extends  WC_Widget
 */

/*Extend widget Woocommerce Product Categories*/

class __TM_Product_Categories_Widget extends WC_Widget_Product_Categories {
	/**
	 * Category ancestors.
	 *
	 * @var array
	 */
	public $cat_ancestors;

	/**
	 * Current Category.
	 *
	 * @var bool
	 */
	public $current_cat;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();

		$tm_wc = new TM_Woocommerce;

		$this->widget_cssclass    = 'woocommerce widget_product_categories_image';
		$this->widget_description = __( 'A list of product image categories.', 'tm-woocommerce-package' );
		$this->widget_id          = 'woocommerce_image_product_categories';
		$this->widget_name        = __( 'TM Product categories with thumbnail', 'tm-woocommerce-package' );

		$this->settings['tm_categories_carousel_widget_visible'] = array(
			'type'  => 'number',
			'step'  => 1,
			'min'   => 1,
			'max'   => 4,
			'std'   => 4,
			'label' => __( 'Number of visible categories', 'tm-woocommerce-package' )
		);

		$this->settings['tm_categories_carousel_widget_navigation'] = array(
			'type'  => 'label',
			'std'   => '',
			'label' => __( 'Navigation', 'tm-woocommerce-package' )
		);

		$this->settings['tm_categories_carousel_widget_arrows'] = array(
			'type'  => 'checkbox',
			'std'   => 1,
			'label' => __( 'Arrows', 'tm-woocommerce-package' )
		);

		$this->settings['tm_categories_carousel_widget_pagination'] = array(
			'type'  => 'checkbox',
			'std'   => 0,
			'label' => __( 'Pagination', 'tm-woocommerce-package' )
		);

		unset( $this->settings['dropdown'] );
		unset( $this->settings['hierarchical'] );
		unset( $this->settings['show_children_only'] );

		WC_Widget::__construct();

		// Include swiper styles, jquery plugin and init to page
		if ( is_active_widget(false, false, $this->id_base, true) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 9 );
		}
	}

	public function enqueue_assets() {
		wp_enqueue_style( 'jquery-swiper' );
		wp_enqueue_script( 'tm-categories-carousel-widget-init' );
	}

	/**
	 * Output widget.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {

		global $wp_query, $post;

		$count        = isset( $instance['count'] ) ? $instance['count'] : $this->settings['count']['std'];
		$orderby      = isset( $instance['orderby'] ) ? $instance['orderby'] : $this->settings['orderby']['std'];
		$hide_empty   = isset( $instance['hide_empty'] ) ? $instance['hide_empty'] : $this->settings['hide_empty']['std'];
		$list_args    = array( 'show_count' => $count, 'hierarchical' => false, 'taxonomy' => 'product_cat', 'hide_empty' => $hide_empty );
		$visible = isset( $instance['tm_categories_carousel_widget_visible'] ) ? $instance['tm_categories_carousel_widget_visible'] : 4;

		$visible = apply_filters( 'tm_categories_carousel_widget_visible', $visible, $args );

		// Menu Order
		$list_args['menu_order'] = false;
		if ( $orderby == 'order' ) {
			$list_args['menu_order'] = 'asc';
		} else {
			$list_args['orderby']    = 'title';
		}

		// Setup Current Category
		$this->current_cat   = false;
		$this->cat_ancestors = array();

		if ( is_tax( 'product_cat' ) ) {

			$this->current_cat   = $wp_query->queried_object;
			$this->cat_ancestors = get_ancestors( $this->current_cat->term_id, 'product_cat' );

		} elseif ( is_singular( 'product' ) ) {

			$product_category = wc_get_product_terms( $post->ID, 'product_cat', array( 'orderby' => 'parent' ) );

			if ( $product_category ) {
				$this->current_cat   = end( $product_category );
				$this->cat_ancestors = get_ancestors( $this->current_cat->term_id, 'product_cat' );
			}

		}

		$uniqid = uniqid();

		$list_args['title_li']                   = '';
		$list_args['pad_counts']                 = 1;
		$list_args['show_option_none']           = __( 'No product categories exist.', 'woocommerce' );
		$list_args['current_category']           = ( $this->current_cat ) ? $this->current_cat->term_id : '';
		$list_args['current_category_ancestors'] = $this->cat_ancestors;

		$arrows = ( ! empty( $instance['tm_categories_carousel_widget_arrows'] ) ) ? $instance['tm_categories_carousel_widget_arrows'] : 0;
		$pagination = ( ! empty( $instance['tm_categories_carousel_widget_pagination'] ) ) ? $instance['tm_categories_carousel_widget_pagination'] : 0;

		$cats = get_terms( 'product_cat', $list_args );

		if( ! empty( $cats ) ) {

			$this->widget_start( $args, $instance );

			if( count( $cats ) < $visible ) {
				$visible = count( $cats );
			}

			$between = apply_filters( 'tm_categories_carousel_widget_space_between_slides', 30 );
			$arrows_pos = apply_filters( 'tm_categories_carousel_widget_arrows_pos', 'inside' );

			$data_attrs[] = 'data-uniq-id="swiper-carousel-' . $uniqid . '"';
			$data_attrs[] = 'data-slides-per-view="' . $visible . '"';
			$data_attrs[] = 'data-slides-per-group="1"';
			$data_attrs[] = 'data-slides-per-column="1"';
			$data_attrs[] = 'data-space-between-slides="' . $between . '"';
			$data_attrs[] = 'data-duration-speed="500"';
			$data_attrs[] = 'data-swiper-loop="false"';
			$data_attrs[] = 'data-free-mode="false"';
			$data_attrs[] = 'data-grab-cursor="true"';
			$data_attrs[] = 'data-mouse-wheel="false"';

			$start_html[] = '<div class="woocommerce swiper-container tm-categories-carousel-widget-container" id="swiper-carousel-' . $uniqid . '" ' . implode( " ", $data_attrs ) . '>';
			$start_html[] = '<ul class="swiper-wrapper tm-categories-carousel-widget-wrapper">';

			echo implode( "\n", $start_html );

			add_filter( 'product_cat_class', 'tm_categories_carousel_widget_product_cat_class' );
			add_filter( 'loop_shop_columns', 'tm_woocommerce_loop_shop_columns' );

			foreach ( $cats as $category ) {
				wc_get_template( 'content-product_cat.php', array(
					'category' => $category,
					'no_grid' => true,
				) );
			}

			global $wp_filter;

			remove_filter( 'loop_shop_columns', 'tm_woocommerce_loop_shop_columns' );
			remove_filter( 'product_cat_class', 'tm_categories_carousel_widget_product_cat_class' );
			woocommerce_reset_loop();

			foreach( $wp_filter['loop_shop_columns'] as $filter ) {
				foreach( $filter as $key => $filter_args ) {
					add_filter( 'loop_shop_columns', $key );
				}
			}

			$end_html[] = '</ul>';
			if( 'outside' === $arrows_pos ){
				$end_html[] = '</div>';
			}

			if($pagination){
				$end_html[] = '<div id="swiper-carousel-'. $uniqid . '-pagination" class="swiper-pagination tm-categories-carousel-widget-pagination"></div>';
			}
			if($arrows){
				$end_html[] = '<div id="swiper-carousel-'. $uniqid . '-next" class="swiper-button-next tm-categories-carousel-widget-button-next">' . do_action( 'tm_categories_carousel_widget_next_arrow_icon' ) . '</div>';
				$end_html[] = '<div id="swiper-carousel-'. $uniqid . '-prev" class="swiper-button-prev tm-categories-carousel-widget-button-prev">' . do_action( 'tm_categories_carousel_widget_prev_arrow_icon' ) . '</div>';
			}
			if( 'inside' === $arrows_pos ){
				$end_html[] = '</div>';
			}

			echo implode( "\n", $end_html );

			$this->widget_end( $args );
		}
	}
}