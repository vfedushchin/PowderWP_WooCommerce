=== TM WooCommerce Package ===

Contributors: TemplateMonster 2002
Tags: woocommerce, widgets, e-commerce
Requires at least: 4.4
Tested up to: 4.4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The plugin based on WooCommerce is packed with multiple functional widgets that give you an opportunity to build various layouts for your store.

== Description ==

Use these professionally designed widgets to create a full-fledged online store. Create beautiful widgets products and categories, banners, store description, and more! You will be able to use the Carousel widget, the SmartBox one, the about store widget and the banner grid widget.

== Installation ==

1. Upload "TM WooCommerce Package" folder to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress
3. Navigate to the "Widgets" section to start customizing

== Changelog ==

= 1.0.0 =

* Initial release